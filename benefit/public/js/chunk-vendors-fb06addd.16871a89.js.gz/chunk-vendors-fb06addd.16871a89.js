"use strict";(self["webpackChunkbenefit"]=self["webpackChunkbenefit"]||[]).push([[3808],{76202:function(t,n,e){var o=e(9495),r=e(47149),c=e(65253),i=e(32019),s=e(92619),u=e(8982),a=e(40154),l=e(63990),d=e(72335),C=e(45247),f=e(90085),R=e(1806),p=e(73844),h=e(25007),v=e(37913),x=e(97743),y=e(21119),$=e(78060),g=e(83312),b=e(84631),m=e(8537),O=e(82339),w=e(65514),F=e(72517),N=e(17845),S=e(36951),I=e(36446),L=e(35960),A=e(47357),D=e(8993),V=e(37053),z=e(24973),k=e(66045),W=e(91241),H=e(4879),X=e(14992),j=e(7664),M=e(94948),U=e(15354),G=e(86856),Y=e(16998),K=e(97591),E=e(5171),q=e(99590),J=e(46355),T=e(14947),Z=e(86099),_=e(48689),B=e(7530),Q=e(31345),P=e(72718),tt=e(46321),nt=e(93057),et=e(73525),ot=e(83910),rt=e(29450),ct=e(98134),it=e(70324),st=e(89805),ut=e(37664),at=e(99893),lt=e(54087),dt=e(15328),Ct=e(11261),ft=e(39882),Rt=e(65057),pt=e(66900),ht=e(23706),vt=e(95171),xt=e(379),yt=e(77723),$t=e(66696),gt=e(39803),bt=e(83834),mt=e(95442),Ot=e(3872),wt=e(66921),Ft=e(26132),Nt=e(4094),St=e(22970),It=e(71739),Lt=e(12462),At=e(57133),Dt=e(4873),Vt=e(10695),zt=e(6489),kt=e(89193),Wt=e(82795),Ht=e(23007),Xt=e(18801),jt=e(92914),Mt=e(65886),Ut=e(17249),Gt=e(97745),Yt=e(28333),Kt=e(69941),Et=e(25621),qt=e(94449),Jt=e(19013),Tt=e(89488),Zt=e(26041),_t=e(40279),Bt=e(73816),Qt=e(14669),Pt=e(70318),tn=e(98890),nn=e(62642),en=e(64635),on=e(54532),rn=e(92616),cn=e(48223),sn=e(14899),un=e(74952),an=e(73008),ln=e(53874),dn=e(67926),Cn=e(39264),fn=e(4313),Rn=e(4490),pn=e(49649),hn=e(37647),vn=e(14421),xn=e(94043),yn=e(2249),$n=e(68889),gn=e(43137),bn=e(96017),mn=e(86567),On=e(24929),wn=e(84745),Fn=e(34733),Nn=e(35137),Sn=e(33556),In=e(51361),Ln=e(64770),An=e(24129),Dn=e(43168),Vn=e(60739),zn=e(49627),kn=e(29547),Wn=e(62667),Hn=e(68065),Xn=e(50894),jn=e(49442),Mn=e(25103),Un=e(58137),Gn=e(40257),Yn=e(80809),Kn=e(63575),En=e(5643),qn=e(12030),Jn=e(55571),Tn=e(44342),Zn=e(97667),_n=e(5466),Bn=e(79862),Qn=e(13726),Pn=e(64593),te=e(38483),ne=e(19327),ee=e(43178),oe=e(85048),re=e(70637),ce=e(74021),ie=e(72641),se=e(31137),ue=e(58246),ae=e(29154),le=e(41719),de=e(50307),Ce=e(30097);
/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
const fe=[r.l,c.l,i.t,s.D,u.U,a.y,l.k,d.l,C.n,f.l,R.S,p.M,h.L,v.r,x.l,y.R,$.O,g.m,b.$,m.X,O.V,w.e,F.l,N.LY,S.N,I.M,L.u,A.F,D.v,V.t,z.V,k.x,W.r,H.f,X.i,j.i,M.Y,U.o,G.k,Y.O,K.T,E.$,q.Y,J.R,T.v,Z.n,_.V,B.O,Q.F,P._,tt.J,nt.x,et.R,ot._,rt.AC,ct.a,it.Y,st.N,ut.u,at.D,lt.H,dt.U,Ct.y,ft.q,Rt.l,pt.K,ht.a,vt.x,xt.V,yt.F,$t.c,gt.l,bt.K,mt.I,Ot.I,wt.zp,Ft.Y,Nt.Q,St.o,It.F,Lt.W,At.V,Dt.f,Vt.r,zt.x,kt.j,Wt.l,Ht.l,Xt.$,jt.A,Mt.S,Ut.P,Gt.l,Yt.M,Kt.j,Et.N,qt.V,Jt.X,Tt.a,Zt.t,_t.h,Bt.m,Qt.F,Pt.u,tn.A,nn._,en.h,on.q,rn.e,cn.j,sn.HK,un.S,an.i,ln.Y,dn.g,Cn.i,fn.r,Rn.G,pn.l,hn.z,vn.X,xn.V,yn.T,$n.j,gn.j,bn.n,mn.r,On.f,wn.$,Fn.L,Nn.H,Sn.M,In.z,Ln.k,An.X,Dn.C,Vn.b,zn.$,kn.l,Wn.$,Hn.Z,Xn.W,jn.K,Mn.F,Un.v,Gn.j,Yn.x,Kn.t,En.F,qn.e,Jn.b,Tn.C,Zn.t,_n.c,Bn.Q,Qn.o,Pn.J,te.Z,ne.q,ee.W,oe.i,re.B,ce.n,ie.p,se.N,ue.W,ae.a,le.B,de.b,Ce.Z];for(const Re of fe)(0,o.tAK)(Re)},1404:function(t,n,e){e.d(n,{R:function(){return c}});var o=e(22792),r=e(92394);
/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
class c{constructor(t,n){this.variableNames=["A"],this.packedInputs=!0,this.packedOutput=!0,this.customUniforms=[{name:"inputShape",type:"ivec3"}],this.outputShape=t,this.enableShapeUniforms=(0,o.ik)(this.outputShape.length);let e="";for(let o=0;o<4;o++){let t="thisRC = rc;";o%2===1&&(t+="thisRC.z += 1;"),o>1&&(t+="thisRC.y += 1;"),e+=`\n        ${t}\n        ${o>0?"if(thisRC.y < rows && thisRC.z < cols){":""}\n          int flatIndex = getFlatIndex(thisRC);\n\n          ivec3 inputRC = inputCoordsFromReshapedOutCoords(flatIndex);\n          vec2 inputRCInnerDims = vec2(float(inputRC.y),float(inputRC.z));\n\n          result[${o}] =\n            getChannel(getA(inputRC.x, inputRC.y, inputRC.z), inputRCInnerDims);\n        ${o>0?"}":""}\n      `}this.userCode=`\n      ${i(n,this.enableShapeUniforms)}\n      ${this.enableShapeUniforms?r.Od():r.fM(t)}\n\n      void main() {\n        ivec3 rc = getOutputCoords();\n\n        vec4 result = vec4(0.);\n\n        ivec3 thisRC;\n        int rows = ${this.enableShapeUniforms?"outShape[1]":t[1]};\n        int cols = ${this.enableShapeUniforms?"outShape[2]":t[2]};\n\n        ${e}\n\n        setOutput(result);\n      }\n    `}}function i(t,n){const e=n?r.TN(["r","c","d"],"inputShape"):r.UG(["r","c","d"],t);return`\n    ivec3 inputCoordsFromReshapedOutCoords(int index) {\n      ${e}\n      return ivec3(r, c, d);\n    }\n  `}},47791:function(t,n,e){e.d(n,{h:function(){return o}});
/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
class o{constructor(t,n,e){this.variableNames=["dy"],this.outputShape=[],this.outputShape=n;const[,o,r]=n,[,c,i]=t,s=[e&&c>1?o-1:o,e&&i>1?r-1:r],u=[e&&c>1?c-1:c,e&&i>1?i-1:i],a=s[0]/u[0],l=s[1]/u[1],d=1/a,C=1/l,f=2*Math.ceil(d)+2,R=2*Math.ceil(C)+2;this.userCode=`\n      void main() {\n        ivec4 coords = getOutputCoords();\n        int b = coords[0];\n        int d = coords[3];\n        int r = coords[1];\n        int c = coords[2];\n\n        float accumulator = 0.0;\n\n        const float heightScale = float(${a});\n        const float widthScale = float(${l});\n\n        const float invHeightScale = float(${d});\n        const float invWidthScale = float(${C});\n\n        const int winHeight = int(${f});\n        const int winWidth = int(${R});\n\n        // Compute bounds for where in dy we will look\n        float startRLerp = floor(float(r) * invHeightScale);\n        int startDyR = int(startRLerp - float(winHeight / 2));\n\n        float startCLerp = floor(float(c) * invWidthScale);\n        int startDyC = int(startCLerp - float(winWidth / 2));\n\n        // Loop over dy\n        for (int dyROffset = 0; dyROffset < winHeight; dyROffset++) {\n          int dyR = dyROffset + startDyR;\n\n          // Guard against the window exceeding the bounds of dy\n          if (dyR < 0 || dyR >= ${c}) {\n            continue;\n          }\n\n          for (int dyCOffset = 0; dyCOffset < winWidth; dyCOffset++) {\n            int dyC = dyCOffset + startDyC;\n\n            // Guard against the window exceeding the bounds of dy\n            if (dyC < 0 || dyC >= ${i}) {\n              continue;\n            }\n\n            float dxR = float(dyR) * heightScale;\n            int topDxRIndex = int(floor(dxR));\n            int bottomDxRIndex = int(min(ceil(dxR), ${o-1}.0));\n            float dxRLerp = dxR - float(topDxRIndex);\n            float inverseDxRLerp = 1.0 - dxRLerp;\n\n            float dxC = float(dyC) * widthScale;\n            int leftDxCIndex = int(floor(dxC));\n            int rightDxCIndex = int(min(ceil(dxC), ${r-1}.0));\n            float dxCLerp = dxC - float(leftDxCIndex);\n            float inverseDxCLerp = 1.0 - dxCLerp;\n\n            if (r == topDxRIndex && c == leftDxCIndex) {\n              // topLeft\n              accumulator +=\n                getDy(b, dyR, dyC, d) * inverseDxRLerp * inverseDxCLerp;\n            }\n\n            if (r == topDxRIndex && c == rightDxCIndex) {\n              // topRight\n              accumulator += getDy(b, dyR, dyC, d) * inverseDxRLerp * dxCLerp;\n            }\n\n            if (r == bottomDxRIndex && c == leftDxCIndex) {\n              // bottomLeft\n              accumulator += getDy(b, dyR, dyC, d) * dxRLerp * inverseDxCLerp;\n            }\n\n            if (r == bottomDxRIndex && c == rightDxCIndex) {\n              // bottomRight\n              accumulator += getDy(b, dyR, dyC, d) * dxRLerp * dxCLerp;\n            }\n          }\n        }\n        // End loop over dy\n\n        setOutput(accumulator);\n      }\n    `}}},26180:function(t,n,e){e.d(n,{z:function(){return o}});
/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
class o{constructor(t,n,e,o,r){this.variableNames=["A"],this.outputShape=[];const[c,i,s,u]=t;this.outputShape=[c,n,e,u];const a=[o&&n>1?i-1:i,o&&e>1?s-1:s],l=[o&&n>1?n-1:n,o&&e>1?e-1:e];let d;d=r?"(vec2(yRC) + vec2(0.5)) * effectiveInputOverOutputRatioRC - vec2(0.5)":"vec2(yRC) * effectiveInputOverOutputRatioRC",this.userCode=`\n      const vec2 effectiveInputOverOutputRatioRC = vec2(\n          ${a[0]/l[0]},\n          ${a[1]/l[1]});\n      const vec2 inputShapeRC = vec2(${i}.0, ${s}.0);\n\n      void main() {\n        ivec4 coords = getOutputCoords();\n        int b = coords[0];\n        int d = coords[3];\n        ivec2 yRC = coords.yz;\n\n        // Fractional source index.\n        vec2 sourceFracIndexRC = ${d};\n\n        // Compute the four integer indices.\n        ivec2 sourceFloorRC = ivec2(max(sourceFracIndexRC, vec2(0.0)));\n        ivec2 sourceCeilRC = ivec2(\n          min(inputShapeRC - 1.0, ceil(sourceFracIndexRC)));\n\n        float topLeft = getA(b, sourceFloorRC.x, sourceFloorRC.y, d);\n        float bottomLeft = getA(b, sourceCeilRC.x, sourceFloorRC.y, d);\n        float topRight = getA(b, sourceFloorRC.x, sourceCeilRC.y, d);\n        float bottomRight = getA(b, sourceCeilRC.x, sourceCeilRC.y, d);\n\n        vec2 fracRC = sourceFracIndexRC - vec2(sourceFloorRC);\n\n        float top = topLeft + (topRight - topLeft) * fracRC.y;\n        float bottom = bottomLeft + (bottomRight - bottomLeft) * fracRC.y;\n        float newValue = top + (bottom - top) * fracRC.x;\n\n        setOutput(newValue);\n      }\n    `}}},16853:function(t,n,e){e.d(n,{x:function(){return o}});
/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
class o{constructor(t,n,e,o,r){this.variableNames=["A"],this.packedInputs=!0,this.packedOutput=!0,this.outputShape=[];const[c,i,s,u]=t;this.outputShape=[c,n,e,u];const a=[o&&n>1?i-1:i,o&&e>1?s-1:s],l=[o&&n>1?n-1:n,o&&e>1?e-1:e];let d;d=r?"(vec3(yRC) + vec3(0.5)) * effectiveInputOverOutputRatioRC - vec3(0.5)":"vec3(yRC) * effectiveInputOverOutputRatioRC",this.userCode=`\n      const vec3 effectiveInputOverOutputRatioRC = vec3(\n          ${a[0]/l[0]},\n          ${a[1]/l[1]},\n          ${a[1]/l[1]});\n      const vec3 inputShapeRC = vec3(${i}.0, ${s}.0,\n                                     ${s}.0);\n\n      float getAValue(int b, int r, int c, int d) {\n        return getChannel(getA(b, r, c, d), vec2(c, d));\n      }\n\n      void main() {\n        ivec4 coords = getOutputCoords();\n        int b = coords[0];\n        int d = coords[3];\n        // Calculate values for next column in yRC.z.\n        ivec3 yRC = coords.yzz + ivec3(0, 0, 1);\n\n        // Fractional source index.\n        vec3 sourceFracIndexRC = ${d};\n\n        // Compute the four integer indices.\n        ivec3 sourceFloorRC = ivec3(max(sourceFracIndexRC, vec3(0.0)));\n        ivec3 sourceCeilRC = ivec3(\n          min(inputShapeRC - 1.0, ceil(sourceFracIndexRC)));\n\n        // Should we calculate next column and row elements in 2x2 packed cell.\n        bool hasNextCol = d < ${u-1};\n        bool hasNextRow = coords.z < ${e-1};\n\n        // In parallel, construct four corners for all four components in\n        // packed 2x2 cell.\n        vec4 topLeft = vec4(\n          getAValue(b, sourceFloorRC.x, sourceFloorRC.y, d),\n          hasNextCol ? getAValue(b, sourceFloorRC.x, sourceFloorRC.y, d + 1)\n                     : 0.0,\n          hasNextRow ? getAValue(b, sourceFloorRC.x, sourceFloorRC.z, d)\n                     : 0.0,\n          (hasNextRow && hasNextCol) ?\n            getAValue(b, sourceFloorRC.x, sourceFloorRC.z, d + 1) : 0.0);\n\n        vec4 bottomLeft = vec4(\n          getAValue(b, sourceCeilRC.x, sourceFloorRC.y, d),\n          hasNextCol ? getAValue(b, sourceCeilRC.x, sourceFloorRC.y, d + 1)\n                     : 0.0,\n          hasNextRow ? getAValue(b, sourceCeilRC.x, sourceFloorRC.z, d)\n                     : 0.0,\n          (hasNextRow && hasNextCol) ?\n            getAValue(b, sourceCeilRC.x, sourceFloorRC.z, d + 1) : 0.0);\n\n        vec4 topRight = vec4(\n          getAValue(b, sourceFloorRC.x, sourceCeilRC.y, d),\n          hasNextCol ? getAValue(b, sourceFloorRC.x, sourceCeilRC.y, d + 1)\n                     : 0.0,\n          hasNextRow ? getAValue(b, sourceFloorRC.x, sourceCeilRC.z, d)\n                     : 0.0,\n          (hasNextRow && hasNextCol) ?\n            getAValue(b, sourceFloorRC.x, sourceCeilRC.z, d + 1) : 0.0);\n\n        vec4 bottomRight = vec4(\n          getAValue(b, sourceCeilRC.x, sourceCeilRC.y, d),\n          hasNextCol ? getAValue(b, sourceCeilRC.x, sourceCeilRC.y, d + 1)\n                     : 0.0,\n          hasNextRow ? getAValue(b, sourceCeilRC.x, sourceCeilRC.z, d)\n                     : 0.0,\n          (hasNextRow && hasNextCol) ?\n            getAValue(b, sourceCeilRC.x, sourceCeilRC.z, d + 1) : 0.0);\n\n        vec3 fracRC = sourceFracIndexRC - vec3(sourceFloorRC);\n\n        vec4 top = mix(topLeft, topRight, fracRC.yyzz);\n        vec4 bottom = mix(bottomLeft, bottomRight, fracRC.yyzz);\n        vec4 newValue = mix(top, bottom, fracRC.x);\n\n        setOutput(newValue);\n      }\n    `}}},27436:function(t,n,e){e.d(n,{x:function(){return o}});
/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
class o{constructor(t,n,e){this.variableNames=["dy"],this.outputShape=[],this.outputShape=n;const[,o,r]=n,[,c,i]=t,s=[e&&c>1?o-1:o,e&&i>1?r-1:r],u=[e&&c>1?c-1:c,e&&i>1?i-1:i],a=s[0]/u[0],l=s[1]/u[1],d=1/a,C=1/l,f=2*Math.ceil(d)+2,R=2*Math.ceil(C)+2;this.userCode=`\n      void main() {\n        ivec4 coords = getOutputCoords();\n        int b = coords[0];\n        int d = coords[3];\n        int r = coords[1];\n        int c = coords[2];\n\n        float accumulator = 0.0;\n\n        const float heightScale = float(${a});\n        const float widthScale = float(${l});\n\n        const float invHeightScale = float(${d});\n        const float invWidthScale = float(${C});\n\n        const int winHeight = int(${f});\n        const int winWidth = int(${R});\n\n        // Compute bounds for where in dy we will look\n        float startRLerp = floor(float(r) * invHeightScale);\n        int startDyR = int(floor(startRLerp - float(winHeight / 2)));\n\n        float startCLerp = floor(float(c) * invWidthScale);\n        int startDyC = int(floor(startCLerp - float(winWidth / 2)));\n\n        // Loop over dy\n        for (int dyROffset = 0; dyROffset < winHeight; dyROffset++) {\n          int dyR = dyROffset + startDyR;\n\n          // Guard against the window exceeding the bounds of dy\n          if (dyR < 0 || dyR >= ${c}) {\n            continue;\n          }\n\n          for (int dyCOffset = 0; dyCOffset < winWidth; dyCOffset++) {\n            int dyC = dyCOffset + startDyC;\n\n            // Guard against the window exceeding the bounds of dy\n            if (dyC < 0 || dyC >= ${i}) {\n              continue;\n            }\n\n            float sourceFracRow =\n              float(${s[0]}) *\n                (float(dyR) / float(${u[0]}));\n\n            float sourceFracCol =\n                float(${s[1]}) *\n                  (float(dyC) / float(${u[1]}));\n\n            int sourceNearestRow = int(min(\n                float(int(${o}) - 1),\n                ${e} ? float(round(sourceFracRow)) :\n                                  float(floor(sourceFracRow))));\n\n            int sourceNearestCol = int(min(\n                float(int(${r}) - 1),\n                ${e} ? float(round(sourceFracCol)) :\n                                  float(floor(sourceFracCol))));\n\n            if (r == sourceNearestRow && c == sourceNearestCol) {\n              accumulator += getDy(b, dyR, dyC, d);\n            }\n          }\n        }\n        // End loop over dy\n\n        setOutput(accumulator);\n      }\n    `}}},6917:function(t,n,e){e.d(n,{$:function(){return o}});
/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
class o{constructor(t,n,e,o,r){this.variableNames=["A"],this.outputShape=[];const[c,i,s,u]=t;this.outputShape=[c,n,e,u];const a=[o&&n>1?i-1:i,o&&e>1?s-1:s],l=[o&&n>1?n-1:n,o&&e>1?e-1:e],d=o?"0.5":"0.0";let C;C=r?"max((vec2(yRC) + vec2(0.5)) * effectiveInputOverOutputRatioRC, vec2(0.0))":"vec2(yRC) * effectiveInputOverOutputRatioRC",this.userCode=`\n      const vec2 effectiveInputOverOutputRatioRC = vec2(\n          ${a[0]/l[0]},\n          ${a[1]/l[1]});\n      const vec2 inputShapeRC = vec2(${i}.0, ${s}.0);\n\n      void main() {\n        ivec4 coords = getOutputCoords();\n        int b = coords[0];\n        int d = coords[3];\n        ivec2 yRC = coords.yz;\n\n        // Fractional source index.\n        vec2 sourceFracIndexRC = ${C};\n\n        // Compute the coordinators of nearest neighbor point.\n        ivec2 sourceNearestRC = ivec2(\n          min(inputShapeRC - 1.0, floor(sourceFracIndexRC + ${d})));\n        float newValue = getA(b, sourceNearestRC.x, sourceNearestRC.y, d);\n\n        setOutput(newValue);\n      }\n    `}}},59250:function(t,n,e){e.d(n,{z:function(){return o}});
/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
class o{constructor(t,n,e,o,r){this.variableNames=["A"],this.packedInputs=!0,this.packedOutput=!0,this.outputShape=[];const[c,i,s,u]=t;this.outputShape=[c,n,e,u];const a=[o&&n>1?i-1:i,o&&e>1?s-1:s],l=[o&&n>1?n-1:n,o&&e>1?e-1:e],d=o?"0.5":"0.0";let C;C=r?"max((vec3(yRC) + vec3(0.5)) * effectiveInputOverOutputRatioRC, vec3(0.0))":"vec3(yRC) * effectiveInputOverOutputRatioRC",this.userCode=`\n      const vec3 effectiveInputOverOutputRatioRC = vec3(\n          ${a[0]/l[0]},\n          ${a[1]/l[1]},\n          ${a[1]/l[1]});\n      const vec3 inputShapeRC = vec3(${i}.0, ${s}.0,\n                                     ${s}.0);\n\n      float getAValue(int b, int r, int c, int d) {\n        return getChannel(getA(b, r, c, d), vec2(c, d));\n      }\n\n      void main() {\n        ivec4 coords = getOutputCoords();\n        int b = coords[0];\n        int d = coords[3];\n        // Calculate values for next column in yRC.z.\n        ivec3 yRC = coords.yzz + ivec3(0, 0, 1);\n\n        // Fractional source index.\n        vec3 sourceFracIndexRC = ${C};\n\n        // Compute the coordinators of nearest neighbor point.\n        ivec3 sourceNearestRC = ivec3(\n          min(inputShapeRC - 1.0, floor(sourceFracIndexRC + ${d})));\n\n        // Should we calculate next column and row elements in 2x2 packed cell.\n        bool hasNextCol = d < ${u-1};\n        bool hasNextRow = coords.z < ${e-1};\n\n        vec4 newValue = vec4(\n          getAValue(b, sourceNearestRC.x, sourceNearestRC.y, d),\n          hasNextCol ? getAValue(b, sourceNearestRC.x, sourceNearestRC.y, d + 1)\n                     : 0.0,\n          hasNextRow ? getAValue(b, sourceNearestRC.x, sourceNearestRC.z, d)\n                     : 0.0,\n          (hasNextRow && hasNextCol) ?\n            getAValue(b, sourceNearestRC.x, sourceNearestRC.z, d + 1) : 0.0);\n\n        setOutput(newValue);\n      }\n    `}}},71967:function(t,n,e){e.d(n,{N:function(){return r}});var o=e(27575);
/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */class r{constructor(t,n){this.variableNames=["x"];const e=t.length;if(e>4)throw new Error(`WebGL backend: Reverse of rank-${e} tensor is not yet supported`);if(this.outputShape=t,1===e)return void(this.userCode=`\n        void main() {\n          int coord = getOutputCoords();\n          setOutput(getX(${t[0]} - coord - 1));\n        }\n      `);const r=e=>-1!==n.indexOf(e)&&1!==t[e]?`${t[e]} - coords[${e}] - 1`:`coords[${e}]`,c=t.map(((t,n)=>r(n))).join(","),i=(0,o.bf)(e);this.userCode=`\n      void main() {\n        ${i} coords = getOutputCoords();\n        setOutput(getX(${c}));\n      }\n    `}}},68636:function(t,n,e){e.d(n,{X:function(){return c}});var o=e(75694),r=e(27575);
/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
class c{constructor(t,n){this.variableNames=["x"],this.packedInputs=!0,this.packedOutput=!0;const e=t.length;if(e>4)throw new Error(`WebGL backend: Reverse of rank-${e} tensor is not yet supported`);this.outputShape=t;const c=(0,o.Jp)("rc",e),i=`${c[e-1]} + 1 < ${this.outputShape[e-1]}`,s=`${c[e-2]} + 1 < ${this.outputShape[e-2]}`,u=(0,r.bf)(e);function a(t){return f(t)}function l(t){return t[e-1]="("+t[e-1]+" + 1)",f(t)}function d(t){return t[e-2]="("+t[e-2]+" + 1)",f(t)}function C(t){return t[e-1]="("+t[e-1]+" + 1)",t[e-2]="("+t[e-2]+" + 1)",f(t)}function f(n){const e=t.map(((t,e)=>R(e,n))),o=e.join(","),r=e.slice(-2).join(",");return`getChannel(getX(${o}), vec2(${r}))`}function R(e,o){return-1!==n.indexOf(e)&&1!==t[e]?`${t[e]} - ${o[e]} - 1`:`${o[e]}`}this.userCode=1===e?`\n        void main(){\n          int rc = getOutputCoords();\n          vec4 result = vec4(0.);\n          result.r = getChannel(getX(${t[0]} - rc - 1),\n            ${t[0]} - rc - 1);\n          if(${i}){\n              result.g = getChannel(getX(${t[0]} - (rc  + 1) - 1),\n                ${t[0]} - (rc  + 1) - 1);\n          }\n          setOutput(result);\n        }\n      `:`\n        void main() {\n          ${u} rc = getOutputCoords();\n          vec4 result = vec4(0.);\n          result.r = ${a(c.slice())};\n          if(${i}){\n            result.g = ${l(c.slice())};\n          }\n          if(${s}) {\n            result.b = ${d(c.slice())};\n            if(${i}) {\n              result.a = ${C(c.slice())};\n            }\n          }\n          setOutput(result);\n        }\n    `}}}}]);
//# sourceMappingURL=chunk-vendors-fb06addd.16871a89.js.map