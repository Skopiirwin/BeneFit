"use strict";(self["webpackChunkbenefit"]=self["webpackChunkbenefit"]||[]).push([[6319],{1802:function(t,e,n){n.d(e,{px:function(){return i}});var r=n(9495),o=n(45705),s=n(21694);
/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the License);
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
const i=(0,o.o)((t=>Math.log(t))),a=(0,s.F)(r.tG8,i);r.tG8},3759:function(t,e,n){n.d(e,{j:function(){return o}});var r=n(9495);
/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function o(t,e,n,o){const s=r.ZSL.getTypedArrayFromDType(o,r.ZSL.sizeFromShape(n));for(let r=0;r<s.length;++r){const n=r*e;let o=t[n];for(let r=0;r<e;++r){const e=t[n+r];(Number.isNaN(e)||e>o)&&(o=e)}s[r]=o}return s}},66114:function(t,e,n){n.d(e,{He:function(){return i}});var r=n(9495),o=n(8195),s=n(98880);
/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
const i=(0,o.Z)(((t,e)=>Math.max(t,e))),a=(0,s.j)(r.LDN,i);r.LDN},48580:function(t,e,n){n.d(e,{hE:function(){return i}});var r=n(9495),o=n(8195),s=n(98880);
/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
const i=(0,o.Z)(((t,e)=>Math.min(t,e))),a=(0,s.j)(r.LG0,i);r.LG0},65646:function(t,e,n){n.d(e,{BF:function(){return i}});var r=n(9495),o=n(8195),s=n(98880);
/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
const i=(0,o.Z)(((t,e)=>t*e)),a=(0,s.B)(((t,e,n,r)=>({real:t*n-e*r,imag:t*r+e*n}))),l=(0,s.j)(r.xu7,i,a);r.xu7},37962:function(t,e,n){n.d(e,{Dk:function(){return i}});var r=n(9495),o=n(97870),s=n(65646);
/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function i(t,e,n){const o=r.ZSL.createScalarValue(-1,n);return(0,s.BF)([],e,o,t,n)}function a(t){const{inputs:e,backend:n}=t,{x:r}=e;(0,o.C)(r,"neg");const s=n.data.get(r.dataId).values,[a,l]=i(s,r.shape,r.dtype);return n.makeTensorInfo(l,r.dtype,a)}r.l0G},97113:function(t,e,n){n.d(e,{cl:function(){return i}});var r=n(9495),o=n(8195),s=n(98880);
/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
const i=(0,o.Z)(((t,e)=>t!==e?1:0)),a=(0,s.j)(r.ylV,i,null,"bool");r.ylV},51675:function(t,e,n){n.d(e,{_B:function(){return i}});var r=n(9495),o=n(97870),s=n(85655);
/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function i(t,e,n,o){const[s,i]=r.C0T.computeOutAndReduceShapes(t,o),a=(0,r.TuY)(e,"int32"),l=r.ZSL.makeZerosTypedArray(r.ZSL.sizeFromShape(s),a),u=r.ZSL.sizeFromShape(i);for(let r=0;r<l.length;++r){const t=r*u;let e=1;for(let r=0;r<u;++r)e*=n[t+r];l[r]=e}return{outVals:l,outShape:s,outDtype:a}}function a(t){const{inputs:e,backend:n,attrs:a}=t,{x:l}=e,{axis:u,keepDims:h}=a;(0,o.C)(l,"prod");const c=l.shape.length,f=r.ZSL.parseAxisParam(u,l.shape),p=r.C0T.getAxesPermutation(f,c);let g=f,d=l;const w=[];null!=p&&(d=(0,s.m)({inputs:{x:l},backend:n,attrs:{perm:p}}),w.push(d),g=r.C0T.getInnerMostAxes(g.length,c));const m=n.data.get(d.dataId).values,{outVals:S,outShape:y,outDtype:T}=i(d.shape,d.dtype,m,g);let v=y;return h&&(v=r.C0T.expandShapeToKeepDim(y,f)),w.forEach((t=>n.disposeIntermediateTensorInfo(t))),n.makeTensorInfo(v,T,S)}r.kdj},15844:function(t,e,n){n.d(e,{u:function(){return c}});var r=n(9495);
/**
 * @license
 * Copyright 2022 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function o(t,e,n){t.forEach(((t,o)=>{if(t<0||t>=n){const s=r.ZSL.indexToLoc(o,e.length,r.ZSL.computeStrides(e)).join(",");throw new Error(`indices[${s}] = ${t} is not in [0, ${n})`)}}))}function s(t,e){for(let n=0;n<t.length;++n){const r=t[n],o=n===t.length-1?e:t[n+1].length;if(0===r.length)throw new Error("Ragged splits may not be empty");if(r[0]<0)throw new Error("Ragged splits must be non-negative");if(r[r.length-1]>o)throw new Error("Ragged splits must not point past values");for(let t=1;t<r.length;++t)if(r[t-1]>r[t])throw new Error("Ragged splits must be sorted in ascending order")}}function i(t,e,n,r){const o=[];let i=0;const a=e.length-1+n.length,l=new Array(a).fill(null).map((()=>[0]));s(n,r);let u=1;for(let s=0;s<e.length-1;++s){u*=e[s];const t=e[s+1];for(let e=1;e<u+1;++e)l[s].push(e*t)}for(let s=0;s<t.length;++s){let r=t[s],a=t[s]+1;for(let t=0;t<n.length;++t){const o=n[t],s=t+e.length-1;if(s>=0){const t=l[s],e=t[t.length-1]-o[r];for(let n=r;n<a;++n)l[s].push(o[n+1]+e)}r=o[r],a=o[a]}a!==r&&(o.push([r,a]),i+=a-r)}return{outSplits:l,valueSlices:o,numValues:i}}function a(t){const e=[];for(let n=0;n<t.length;++n){const o=t[n].length,s=r.ZSL.getArrayFromDType("int32",o);e.push(s),t[n].forEach(((t,e)=>s[e]=t))}return e}function l(t,e){const n=t.slice(0,e);while(n.length<e)n.push(1);for(let r=e;r<t.length;r++)n[e-1]*=t[r];return n}function u(t,e,n,r,o,s){const i=l(e,2)[1],a=l(s,2)[1];let u=0;for(const l of n)for(let e=l[0];e<l[1];++e){for(let n=0;n<r;++n)o[u*a+n]=t[e*i+n];++u}}function h(t,e,n,o,s){const i=e.slice();i[0]=s;const a=r.ZSL.getArrayFromDType(n,r.ZSL.sizeFromShape(i)),l=t.length,h=0===l?0:l/e[0];return u(t,e,o,h,a,i),[a,i]}function c(t,e,n,r,s,l,u,c){if(0===t.length)throw new Error("paramsNestedSplits must be non empty");if(0===e[0].length)throw new Error("Split tensors must not be scalars");const f=e[0][0]-1;if(o(l,u,f),0===r.length)throw new Error("params.rank must be nonzero");const p=r[0],{outSplits:g,valueSlices:d,numValues:w}=i(l,u,t,p),m=a(g),S=h(n,r,s,d,w);return[m,S[0],S[1]]}},47620:function(t,e,n){n.d(e,{_:function(){return s}});var r=n(9495);
/**
 * @license
 * Copyright 2022 Google LLC.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */const o=2147483647;function s(t,e,n,s,i,a,l){if(e.length>1)throw new Error("starts must be a scalar or vector");if(i.length>1)throw new Error("limits must be a scalar or vector");if(l.length>1)throw new Error("deltas must be a scalar or vector");const u=0===e.length,h=0===i.length,c=0===l.length,f=[];u||f.push(e[0]),h||f.push(i[0]),c||f.push(l[0]);for(let r=1;r<f.length;++r)if(f[r]!==f[r-1])throw new Error("starts, limits, and deltas must have the same shape");const p=0===f.length?1:f[0],g=r.ZSL.getArrayFromDType("int32",p+1);g[0]=0;for(let r=0;r<p;++r){const e=u?t[0]:t[r],n=h?s[0]:s[r],i=c?a[0]:a[r];if(0===i)throw new Error("Requires delta != 0");let l;if(i>0&&n<e||i<0&&n>e)l=0;else if(l=Math.ceil(Math.abs((n-e)/i)),l>o)throw new Error(`Requires ((limit - start) / delta) <= ${o}`);g[r+1]=g[r]+l}const d=g[p],w=r.ZSL.getArrayFromDType(n,d);let m=0;for(let r=0;r<p;++r){const e=g[r+1]-g[r];let n=u?t[0]:t[r];const o=c?a[0]:a[r];for(let t=0;t<e;++t)w[m++]=n,n+=o}return[g,w]}},80814:function(t,e,n){n.d(e,{K:function(){return l}});var r=n(9495),o=r.C0T.RowPartitionType;
/**
 * @license
 * Copyright 2022 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */class s{constructor(t,e,n,o,s,i,a,l,u,h){this.shape=t,this.shapeShape=e,this.values=n,this.valuesShape=o,this.valuesDType=s,this.defaultValue=i,this.defaultValueShape=a,this.rowPartitionValues=l,this.rowPartitionValuesShapes=u,this.rowPartitionTypes=r.C0T.getRowPartitionTypesHelper(h),this.raggedRank=r.C0T.getRaggedRank(this.rowPartitionTypes)}getRowPartitionTypeByDimension(t){return this.rowPartitionTypes[0]===o.FIRST_DIM_SIZE?this.rowPartitionTypes[t+1]:this.rowPartitionTypes[t]}getRowPartitionTensor(t){return this.rowPartitionTypes[0]===o.FIRST_DIM_SIZE?this.rowPartitionValues[t+1]:this.rowPartitionValues[t]}getMaxWidth(t){const e=this.getRowPartitionTensor(t-1);switch(this.getRowPartitionTypeByDimension(t-1)){case o.VALUE_ROWIDS:return s.getMaxWidthValueRowID(e);case o.ROW_SPLITS:return s.getMaxWidthRowSplit(e);default:throw new Error(`Cannot handle partition type ${o[this.getRowPartitionTypeByDimension(t-1)]}`)}}static getMaxWidthRowSplit(t){const e=t.length;if(0===e||1===e)return 0;let n=0;for(let r=0;r<e-1;++r){const e=t[r+1]-t[r];e>n&&(n=e)}return n}static getMaxWidthValueRowID(t){const e=t.length;if(0===e)return 0;let n=0,r=t[0],o=0;for(let s=1;s<e;++s){const e=t[s];e!==r&&(r=e,o=Math.max(s-n,o),n=s)}return Math.max(e-n,o)}tensorShapeFromTensor(t,e,n=!0){if(0===e.length){if(-1===t[0])return[];throw new Error("The only valid scalar shape tensor is the fully unknown shape specified as -1.")}return a(t,n)}calculateOutputSize(t){const e=this.valuesShape,n=this.defaultValueShape;r.C0T.validateDefaultValueShape(n,e);const o=this.tensorShapeFromTensor(this.shape,this.shapeShape),s=r.C0T.combineRaggedTensorToTensorShapes(this.raggedRank,o,e),i=s;i[0]<0&&(i[0]=t);for(let r=1;r<=this.raggedRank;++r)i[r]<0&&(i[r]=this.getMaxWidth(r));return i}calculateFirstParentOutputIndex(t,e,n){const o=Math.min(t,n),s=[];let i=0;for(let r=0;r<o;++r,i+=e)s.push(i);for(let r=o;r<t;++r)s.push(-1);return r.ZSL.assert(s.length===t,(()=>"Final length of result must be equal to firstDimension.")),s}calculateOutputIndexRowSplit(t,e,n,r){const o=t.length,s=[];for(let i=0;i<o-1;++i){const o=t[i+1]-t[i];let a=Math.min(r,o),l=e[i];-1===l&&(a=0);for(let t=0;t<a;++t)s.push(l),l+=n;for(let t=0;t<o-a;++t)s.push(-1)}if(o>0&&s.length!==t[o-1])throw new Error("Invalid row split size.");return s}calculateOutputIndexValueRowID(t,e,n,r){const o=t.length,s=[];if(0===o)return[];let i=0,a=t[0];if(a>=e.length)throw new Error(`Got currentValueRowId=${a}, which is not less than ${e.length}`);let l=e[a];s.push(l);for(let u=1;u<o;++u){const o=t[u];if(o===a)l>=0&&(++i,i<r?l+=n:l=-1);else{if(i=0,a=o,o>=e.length)throw new Error(`Got nextValueRowId=${o} which is not less than ${e.length}`);l=e[o]}s.push(l)}if(s.length!==t.length)throw new Error("Invalid row ids.");return s}calculateOutputIndex(t,e,n,r){const s=this.getRowPartitionTensor(t),i=this.getRowPartitionTypeByDimension(t);switch(i){case o.VALUE_ROWIDS:return this.calculateOutputIndexValueRowID(s,e,n,r);case o.ROW_SPLITS:if(s.length-1>e.length)throw new Error(`Row partition size is greater than output size: ${s.length-1} > ${e.length}`);return this.calculateOutputIndexRowSplit(s,e,n,r);default:throw new Error(`Unsupported partition type: ${o[i]}`)}}getFirstDimensionSize(){const t=this.rowPartitionValues[0];if(0===this.rowPartitionTypes.length)throw new Error("No row_partition_types given.");const e=this.rowPartitionTypes[0];switch(e){case o.FIRST_DIM_SIZE:return t[0];case o.VALUE_ROWIDS:throw new Error("Cannot handle VALUE_ROWIDS in first dimension.");case o.ROW_SPLITS:return this.rowPartitionValuesShapes[0][0]-1;default:throw new Error(`Cannot handle type ${o[e]}`)}}compute(){const t=this.rowPartitionValues[0];if(t.length<=0)throw new Error("Invalid first partition input. Tensor requires at least one element.");const e=this.getFirstDimensionSize(),n=this.calculateOutputSize(e),o=new Array(this.raggedRank+1);o[o.length-1]=1;for(let r=o.length-2;r>=0;--r)o[r]=o[r+1]*n[r+1];const s=a(n,!1),i=r.ZSL.getArrayFromDType(this.valuesDType,r.ZSL.sizeFromShape(s)),l=o[0]*n[0];if(l>0){let t=this.calculateFirstParentOutputIndex(e,o[0],n[0]);for(let e=1;e<=this.raggedRank;++e){const r=this.calculateOutputIndex(e-1,t,o[e],n[e]);t=r}this.setOutput(this.raggedRank,t,i,s)}return[s,i]}setOutput(t,e,n,o){if(0===n.length)return;const s=this.values,a=n;let l=o.slice();l=l.slice(t+1);const u=r.ZSL.sizeFromShape(l),h=e.length;let c=this.defaultValue;if(c.length!==u&&1!==c.length){const t=this.defaultValueShape;(0,r.DZQ)((()=>{const e=(0,r.tQQ)(c,t),n=(0,r.hOW)(e,l);c=n.dataSync()}))}let f=0,p=0,g=0;for(let r=0;r<=h;++r){let t=r<h?e[r]:-1;if(t!==g){if(p<g){const t=s.subarray(f*u),e=a.subarray(p*u),n=(g-p)*u;i(e,t,n)}if(r>=h){const e=n.length;t=Math.floor(e/u)}if(t>g)if(1===this.defaultValue.length)a.subarray(g*u,t*u).fill(this.defaultValue[0]),g=t;else while(t>g){const t=a.slice(g*u);i(t,c,u),++g}t<0?(f=r+1,p=g):(f=r,p=g,g=p+1)}else++g}}}function i(t,e,n){for(let r=0;r<n;r++)t[r]=e[r]}function a(t,e){const n=[];for(let r of t){if(r<0){if(!e)throw new Error(`Dimension ${r} must be >= 0`);if(r<-1)throw new Error(`Dimension ${r} must be >= -1`);r=-1}n.push(r)}return n}function l(t,e,n,r,o,i,a,l,u,h){return new s(t,e,n,r,o,i,a,l,u,h).compute()}},52610:function(t,e,n){n.d(e,{q:function(){return o}});var r=n(9495);
/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function o(t,e,n,o){const s=t===e,i=t<e&&n<0,a=e<t&&n>1;if(s||i||a)return r.ZSL.makeZerosTypedArray(0,o);const l=Math.abs(Math.ceil((e-t)/n)),u=r.ZSL.makeZerosTypedArray(l,o);e<t&&1===n&&(n=-1),u[0]=t;for(let r=1;r<u.length;r++)u[r]=u[r-1]+n;return u}},85806:function(t,e,n){n.d(e,{x:function(){return o}});var r=n(9495);
/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function o(t){const{inputs:e,backend:n}=t,{input:r}=e,o=n.data.get(r.dataId).complexTensorInfos.real,s=n.data.get(o.dataId).values;return n.makeTensorInfo(o.shape,o.dtype,s)}r.LRy},4092:function(t,e,n){n.d(e,{Zy:function(){return i}});var r=n(9495),o=n(45705),s=n(21694);
/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the License);
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
const i=(0,o.o)((t=>1/Math.sqrt(t))),a=(0,s.F)(r.TOR,i);r.TOR},19095:function(t,e,n){n.d(e,{b:function(){return o}});var r=n(9495);
/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */function o(t,e,n,o,s,i,a,l,u,h){const c=[o/s,s],f=t.values,p=e.values;if(0===o)return(0,r.ra8)(n,e.dtype);const g=u instanceof r.ylz?u:(0,r.ra8)(c,e.dtype);"string"===typeof u||"number"===typeof u?g.values.fill(u):"boolean"===typeof u&&g.values.fill(+u);for(let r=0;r<i;r++){const t=[];let i=0;for(let e=0;e<a;e++){const n=f[r*a+e];t.push(n),i+=n*l[e]}if(i<0||i>=o/s)throw new Error(`Invalid indices: ${t} does not index into ${n}`);for(let n=0;n<s;n++)h?g.values[i*s+n]+=p[r*s+n]:g.values[i*s+n]=0===e.rank?p[0]:p[r*s+n]}return g}},64904:function(t,e,n){n.d(e,{zv:function(){return i}});var r=n(9495),o=n(45705),s=n(21694);
/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the License);
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
const i=(0,o.o)((t=>1/(1+Math.exp(-t)))),a=(0,s.v)(r.vI1,(t=>1/(1+Math.exp(-t))));r.vI1},87906:function(t,e,n){n.d(e,{HS:function(){return s}});var r=n(9495),o=n(97870);
/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function s(t,e,n,o,s){const i=r.Kro.isSliceContinous(o,e,n),a=r.ZSL.sizeFromShape(n),l=r.ZSL.computeStrides(o);if(i){const n=r.Kro.computeFlatOffset(e,l);return"string"===s?t.slice(n,n+a):t.subarray(n,n+a)}const u="string"===s?r.C0T.fromUint8ToStringArray(t):t,h=(0,r.ra8)(o,s,u),c=(0,r.ra8)(n,s);for(let r=0;r<c.size;++r){const t=c.indexToLoc(r),n=t.map(((t,n)=>t+e[n]));c.set(h.get(...n),...t)}return"string"===s?r.C0T.fromStringArrayToUint8(c.values):c.values}function i(t){const{inputs:e,backend:n,attrs:i}=t,{x:a}=e,{begin:l,size:u}=i;(0,o.C)(a,"slice");const[h,c]=r.Kro.parseSliceParams(a,l,u);r.Kro.assertParamsValid(a,h,c);const f=n.data.get(a.dataId).values,p=s(f,h,c,a.shape,a.dtype);return n.makeTensorInfo(c,a.dtype,p)}r.JiE}}]);
//# sourceMappingURL=chunk-vendors-ce9ae230.6b2b741d.js.map